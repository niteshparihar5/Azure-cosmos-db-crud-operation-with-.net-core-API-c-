﻿using Microsoft.Azure.Documents.Client;
using System.Threading.Tasks;

namespace AzureCosmosDB
{
   
    public interface ICosmosConnection
    {
        Task<DocumentClient> InitializeAsync(string collectionId);
    }
}
